# import test
from test import ifpung
print("함수 사용해보자")

print("나만의 게임시작 !")
print("적이 나타났습니다")
print("어떻게 할래? 1. 펑 2. 뿡 3. 빵 ")

inp = input("입력 : ")
# 여기에 숫자를 넣으면 어떻게 되는지 알려주는 함수 
ifpung(inp)

print("결과는 이렇게 됐습니다 ..")