
# 여기에 숫자를 넣으면 어떻게 되는지 알려주는 함수 
def ifpung(inp):
    if inp == '1':
        print("펑 하고 터졌습니다 ")
    if inp == '2':
        print("뿡 하고 터졌습니다 ")
    if inp == '3':
        print("빵 하고 터졌습니다 ")



